(function(){
  const fab = document.getElementById('chatbot-fab');
  const box = document.getElementById('chatbot-container');
  const closeBtn = document.getElementById('chatbot-close');
  const messagesEl = document.getElementById('chatbot-messages');
  const inputEl = document.getElementById('chatbot-text');
  const sendBtn = document.getElementById('chatbot-send');
  const headerEl = document.getElementById('chatbot-header');
  let isDragging = false, offsetX = 0, offsetY = 0;

  function scrollBottom(){ messagesEl.scrollTop = messagesEl.scrollHeight; }
  function addMsg(role, html){
    const div = document.createElement('div');
    div.className = 'msg ' + (role === 'user' ? 'user' : 'bot');
    div.innerHTML = html; messagesEl.appendChild(div); scrollBottom();
  }
  fab.onclick = () => { box.style.display = 'flex'; };
  closeBtn.onclick = () => { box.style.display = 'none'; };
  function ask(){
    const t = inputEl.value.trim(); if(!t) return;
    addMsg('user', t); inputEl.value='';
    addMsg('bot','준비 중입니다.');
  }
  sendBtn.onclick = ask;
  inputEl.addEventListener('keydown', (e)=>{ if(e.key === 'Enter') ask(); });
  headerEl.addEventListener('mousedown', (e) => {
    isDragging = true;
    const rect = box.getBoundingClientRect();
    if (!box.style.left && !box.style.top) {
      box.style.left = rect.left + 'px'; box.style.top = rect.top + 'px';
      box.style.right = ''; box.style.bottom = '';
    }
    offsetX = e.clientX - rect.left; offsetY = e.clientY - rect.top;
    document.body.style.userSelect = 'none';
  });
  document.addEventListener('mousemove', (e) => {
    if (!isDragging) return;
    let x = e.clientX - offsetX, y = e.clientY - offsetY;
    const maxX = window.innerWidth - box.offsetWidth, maxY = window.innerHeight - box.offsetHeight;
    if (x < 0) x = 0; if (y < 0) y = 0; if (x > maxX) x = maxX; if (y > maxY) y = maxY;
    box.style.left = x + 'px'; box.style.top = y + 'px';
  });
  document.addEventListener('mouseup', () => { if (isDragging) { document.body.style.userSelect = ''; } isDragging = false; });
  addMsg('bot','사고 상황을 입력하면 필요한 정보를 단계적으로 물어보고 안내합니다.');
})();
